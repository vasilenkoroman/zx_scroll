Vertical per pixel full screen scroller for ZX spectrum. 
Designed for Pentagon 128/256/512/1024.
Build number 3.10.

https://github.com/vasilenkoroman/zx_scroll


Change log:
3.7
	initial release
3.10	
	Add .tap version.
	Add one more empty line on page7 during text effect.
	Align int phase fixed 2->1.
	