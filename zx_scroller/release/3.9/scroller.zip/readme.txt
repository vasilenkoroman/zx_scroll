Vertical per pixel full screen scroller for ZX spectrum. 
Designed for Pentagon 128/256/512/1024.
Build number 3.9.

https://github.com/vasilenkoroman/zx_scroll
